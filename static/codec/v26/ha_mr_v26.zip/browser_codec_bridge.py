"""Browser-only bridge for the exact V26 ha.mr codec."""
from ha_mr.codec import (
    ASCII_ALPHABET,
    CJK_ALPHABET,
    CJK_V2_ALPHABET,
    EMOJI_ALPHABET,
    QR_ALPHABET,
    CodecError,
    compress_adaptive,
    decompress_adaptive,
    infer_alphabet,
)

_ALPHABETS = {
    "ascii": ASCII_ALPHABET,
    "emoji": EMOJI_ALPHABET,
    "cjk": CJK_V2_ALPHABET,
    "qr": QR_ALPHABET,
}

def _alphabet(mode):
    try:
        return _ALPHABETS[mode]
    except KeyError as exc:
        raise CodecError("Unknown browser transport mode.") from exc

def compress_url(url, mode):
    return compress_adaptive(str(url), _alphabet(str(mode)))

def decompress_payload(payload, mode):
    return decompress_adaptive(str(payload), _alphabet(str(mode)))

def decompress_auto(payload):
    value = str(payload)
    return decompress_adaptive(value, infer_alphabet(value))
